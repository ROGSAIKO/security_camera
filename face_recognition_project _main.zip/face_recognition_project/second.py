# -*- coding: utf-8 -*-
"""
Created on Sun Nov  7 20:02:20 2021

@author: sai
"""

import numpy as np
import cv2
import face_recognition
import os
from datetime import datetime

#Automate the image retrieval from system throught his pipeline
path = 'warehouse'
images = []
classNames = []
myList = os.listdir(path)
print(myList)

#Reading image by openCV.
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
print(classNames) 
 
#finding encodings for diffrent images.
def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList
encodeListKnown = findEncodings(images)
print('encoding complete')


def mailer(name):
    import smtplib
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login("cruder.101@gmail.com", "Pass@2077")
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    message = name.upper() + " is waiting outside.\nTIME:" + current_time
    s.sendmail("cruder.101@gmail.com", "saiko1824@gmail.com", message)
    s.quit()
    return 0

    
    
    
i=0
j=0
   
cap = cv2.VideoCapture(1)
while True:
    
    success, img = cap.read()
    imgS = cv2.resize(img,(0,0),None,0.25,0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
    
    encode = face_recognition.face_encodings(imgS)
    facesCurFrame = face_recognition.face_locations(imgS)
    encodeCurFrame = face_recognition.face_encodings(imgS,facesCurFrame)
    for encodeFace,faceLoc in zip(encodeCurFrame,facesCurFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        FaceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
        print(FaceDis)
        matchIndex = np.argmin(FaceDis)
        if matches[matchIndex]:
            name = classNames[matchIndex].upper()
            #print(name)
            y1,x2,y2,x1 = faceLoc
            y1, x2, y2, x1 = y1*4, x2*4, y2*4, x1*4
            cv2.rectangle(img,(x1,y1),(x2,y2),(0,255,0),2)
            cv2.rectangle(img,(x1,y2-35),(x2,y2),(0,255,0),cv2.FILLED)
            cv2.putText(img,name,(x1+6,y2-6),cv2.FONT_HERSHEY_COMPLEX,1,(255,255,255),2)
            i=i+1
            if (i>3):
                print(name,"is waiting!")
                mailer(name)
                break;
        else:
            j=j+1
            if(j>4):
                msg = "Stranger is waiting outside!"
                print(msg)
                mailer(msg)
                j=0
                                            
            
    '''cv2.rectangle(img,((faceLoc[3]*4), (faceLoc[0]*4)),((faceLoc[1]*4),(faceLoc[2]*4)),(0,255,0),2)
    #cv2.rectangle(img,((faceLoc[3]*4), (faceLoc[0]*4)-35),((faceLoc[1]*4),(faceLoc[2]*4)),(0,255,0),cv2.FILLED)'''
            
    cv2.imshow('webcam',img)
    cv2.waitKey(1)
    