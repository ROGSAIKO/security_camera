# -*- coding: utf-8 -*-
"""
Created on Thu Oct  7 13:10:47 2021

@author: sai
"""
import numpy as np
import cv2
import face_recognition



"""lOADING AN IMAGE FROM LIBRARY"""
imgElon = face_recognition.load_image_file('lib/bill_gates_1.jpg')
imgElon = cv2.cvtColor(imgElon,cv2.COLOR_BGR2RGB)



""" LOADING A TEST IMAGE """
imgTest = face_recognition.load_image_file('lib/bill_gates_2.jpg')
imgTest = cv2.cvtColor(imgTest,cv2.COLOR_BGR2RGB)



"""LETS CALL THE FACE_RECOGNITION MODULE TO PERFORM FACE RECOGNITION ON BOTH THE IMAGES SEPERATELY"""

#THIS IS THE FIRST IMAGE...
faceLoc = face_recognition.face_locations(imgElon)[0]
encodeElon = face_recognition.face_encodings(imgElon)[0]
cv2.rectangle(imgElon,(faceLoc[3], faceLoc[0]),(faceLoc[1],faceLoc[2]),(0,255,0),4)



#THIS IS THE SECOND IMAGE AKA TEST IMAGE...
faceLocTest = face_recognition.face_locations(imgTest)[0]
encodeTest = face_recognition.face_encodings(imgTest)[0]
cv2.rectangle(imgTest,(faceLocTest[3], faceLocTest[0]),(faceLocTest[1],faceLocTest[2]),(0,255,0),4)
#NOW WE ARE DONE WITH SEPERATELY DOING FACE RECOGNITIONS ON BOTH THE IMAGES...



#let's take a look at how these two face_encodings match with each other,for comparing faces a linearSVM is used.
results = face_recognition.compare_faces([encodeElon],encodeTest)
#Introducing to you the distance parameter that shows the diffrence between the face encodings...
#The lower this figure the better the matchete!
faceDis = face_recognition.face_distance([encodeElon],encodeTest)
print(results, faceDis)
cv2.putText(imgTest, f'{results} {round(faceDis[0],2)}',(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255),4)



"""OUTPUT"""              
cv2.imshow('ELON MUSK', imgElon)
cv2.imshow('ELON MUSK TEST', imgTest)

cv2.waitKey(0)


